package com.example.theeventplansapp.repository

import androidx.room.Query
import com.example.theeventplansapp.database.EventDatabase
import com.example.theeventplansapp.model.Event

class EventRepository(private val db: EventDatabase) {

    suspend fun insertEvent(event: Event) = db.getEventDao().insertEvent(event)
    suspend fun deleteEvent(event: Event) = db.getEventDao().deleteEvent(event)
    suspend fun updateEvent(event: Event) = db.getEventDao().updateEvent(event)

    fun getAllEvents() = db.getEventDao().getAllEvents()
    fun searchEvent(query: String?) = db.getEventDao().searchEvent(query)
}