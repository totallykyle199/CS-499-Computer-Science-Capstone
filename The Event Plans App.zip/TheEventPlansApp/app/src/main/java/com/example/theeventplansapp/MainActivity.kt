package com.example.theeventplansapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.theeventplansapp.database.EventDatabase
import com.example.theeventplansapp.repository.EventRepository
import com.example.theeventplansapp.viewmodel.EventViewModel
import com.example.theeventplansapp.viewmodel.EventViewModelFactory

class MainActivity : AppCompatActivity() {

    lateinit var eventViewModel: EventViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupViewModel()
    }

    private fun setupViewModel(){
        val eventRepository = EventRepository(EventDatabase(this))
        val viewModelProviderFactory = EventViewModelFactory(application, eventRepository)
        eventViewModel = ViewModelProvider(this, viewModelProviderFactory)[EventViewModel::class.java]
    }
}