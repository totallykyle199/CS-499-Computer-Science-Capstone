package com.example.kylelundeventtracker;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Objects;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    private Context context;
    Activity activity;
    private ArrayList event_id, event_title, event_desc, event_date;


    CustomAdapter(Activity activity, Context context, ArrayList event_id, ArrayList event_title, ArrayList event_desc, ArrayList event_date){
        this.activity = activity;
        this.context = context;
        this.event_id = event_id;
        this.event_title = event_title;
        this.event_desc = event_desc;
        this.event_date = event_date;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position){
        holder.event_id_txt.setText(String.valueOf(event_id.get(position)));
        holder.event_title_txt.setText(String.valueOf(event_title.get(position)));
        holder.event_desc_txt.setText(String.valueOf(event_desc.get(position)));
        holder.event_date_txt.setText(String.valueOf(event_date.get(position)));
        holder.mainlayout.setOnClickListener((view) -> {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra( "id", String.valueOf(event_id.get(position)));
                intent.putExtra( "title", String.valueOf(event_title.get(position)));
                intent.putExtra( "desc", String.valueOf(event_desc.get(position)));
                intent.putExtra( "date", String.valueOf(event_date.get(position)));
                activity.startActivityForResult(intent, 1);
        });

    }

    @Override
    public int getItemCount() {
        return event_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView event_id_txt, event_title_txt, event_desc_txt, event_date_txt;
        LinearLayout mainlayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            event_id_txt = itemView.findViewById(R.id.event_id_txt);
            event_title_txt = itemView.findViewById(R.id.event_title_txt);
            event_desc_txt = itemView.findViewById(R.id.event_desc_txt);
            event_date_txt = itemView.findViewById(R.id.event_date_txt);
            mainlayout = itemView.findViewById(R.id.mainLayout);
        }
    }
}
