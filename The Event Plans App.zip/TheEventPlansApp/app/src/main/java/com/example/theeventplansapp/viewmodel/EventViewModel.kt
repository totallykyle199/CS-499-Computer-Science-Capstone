package com.example.theeventplansapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.theeventplansapp.repository.EventRepository
import kotlinx.coroutines.launch

class EventViewModel(app: Application, private val eventRepository: EventRepository): AndroidViewModel(app) {

    fun addEvent(event: com.example.theeventplansapp.model.Event) =
        viewModelScope.launch {
            eventRepository.insertEvent(event)
        }

    fun deleteEvent(event: com.example.theeventplansapp.model.Event) =
        viewModelScope.launch {
            eventRepository.deleteEvent(event)
        }

    fun updateEvent(event: com.example.theeventplansapp.model.Event) =
        viewModelScope.launch {
            eventRepository.updateEvent(event)
        }

    fun getAllEvents() = eventRepository.getAllEvents()

    fun searchEvent(query: String?) =
        eventRepository.searchEvent(query)
}