package com.example.theeventplansapp.fragments

import android.app.AlertDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.lifecycle.Lifecycle
import androidx.navigation.findNavController
import androidx.navigation.fragment.navArgs
import com.example.theeventplansapp.MainActivity
import com.example.theeventplansapp.R
import com.example.theeventplansapp.databinding.FragmentEditEventBinding
import com.example.theeventplansapp.model.Event
import com.example.theeventplansapp.viewmodel.EventViewModel

class EditEventFragment : Fragment(R.layout.fragment_edit_event), MenuProvider {

    private var editEventBinding: FragmentEditEventBinding? = null
    private val binding get() = editEventBinding!!

    private lateinit var eventsViewModel: EventViewModel
    private lateinit var currentEvent: Event

    private val args: EditEventFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        editEventBinding = FragmentEditEventBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(this, viewLifecycleOwner, Lifecycle.State.RESUMED)

        eventsViewModel = (activity as MainActivity).eventViewModel
        currentEvent = args.event!!

        binding.editEventTitle.setText(currentEvent.eventTitle)
        binding.editEventDesc.setText(currentEvent.eventDesc)

        binding.editEventFab.setOnClickListener {
            val eventTitle = binding.editEventTitle.text.toString().trim()
            val eventDesc = binding.editEventDesc.text.toString().trim()

            if (eventTitle.isNotEmpty()){
                val event = Event(currentEvent.id, eventTitle, eventDesc)
                eventsViewModel.updateEvent(event)
                view.findNavController().popBackStack(R.id.homeFragment, false)
            } else {
                Toast.makeText(context, " Please enter event title", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun deleteEvent(){
        AlertDialog.Builder(activity).apply {
            setTitle("Delete Event")
            setMessage("Do you want to delete this event?")
            setPositiveButton("Delete"){_,_ ->
                eventsViewModel.deleteEvent(currentEvent)
                Toast.makeText(context, " Event Deleted", Toast.LENGTH_SHORT).show()
                view?.findNavController()?.popBackStack(R.id.homeFragment, false)
            }
            setNegativeButton("Cancel", null)
        }.create().show()
    }

    override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
        menu.clear()
        menuInflater.inflate(R.menu.menu_edit_event, menu)
    }

    override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
        return when(menuItem.itemId){
            R.id.deleteMenu -> {
                deleteEvent()
                true
            } else -> false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        editEventBinding = null
    }
}