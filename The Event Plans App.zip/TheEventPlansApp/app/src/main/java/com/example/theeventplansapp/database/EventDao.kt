package com.example.theeventplansapp.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.theeventplansapp.model.Event

@Dao
interface EventDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: Event)

    @Update
    suspend fun updateEvent(event: Event)

    @Delete
    suspend fun deleteEvent(event: Event)

    @Query("SELECT * FROM EVENTS ORDER BY id DESC")
    fun getAllEvents(): LiveData<List<Event>>

    @Query("SELECT * FROM EVENTS WHERE eventTitle LIKE :query OR eventDesc LIKE :query")
    fun searchEvent(query: String?): LiveData<List<Event>>
}