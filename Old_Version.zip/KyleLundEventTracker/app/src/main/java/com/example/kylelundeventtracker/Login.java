package com.example.kylelundeventtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Login extends AppCompatActivity {

    EditText username;
    EditText password;
    Button buttonLogin;
    Button buttonRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.textUsername);
        password = findViewById(R.id.textPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().equals("user")&& password.getText().toString().equals("1234")){
                    openActivityWeek();
                }
                else{
                    openActivityWeek();
                }
            }
        });

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText() != null && password.getText() != null) {
                    Toast.makeText(Login.this, "User Registered", Toast.LENGTH_SHORT).show();
                    openActivityWeek();
                }else{

                    Toast.makeText(Login.this, "Please Enter a Username and Password", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void openActivityWeek(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}

