package com.example.theeventplansapp.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

@Entity(tableName = "events")
@Parcelize
data class Event(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val eventTitle: String,
    val eventDesc: String
): Parcelable
