package com.example.theeventplansapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.theeventplansapp.databinding.EventLayoutBinding
import com.example.theeventplansapp.fragments.HomeFragmentDirections
import com.example.theeventplansapp.model.Event

class EventAdapter : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    class EventViewHolder(val itemBinding: EventLayoutBinding): RecyclerView.ViewHolder(itemBinding.root)

    private val differCallback = object : DiffUtil.ItemCallback<Event>(){
        override fun areItemsTheSame(oldItem: Event, newItem: Event): Boolean {
            return oldItem.id == newItem.id &&
                    oldItem.eventDesc == newItem.eventDesc &&
                    oldItem.eventTitle == newItem.eventTitle
        }

        override fun areContentsTheSame(oldItem: Event, newItem: Event): Boolean {
            return oldItem == newItem
        }
    }
    val differ = AsyncListDiffer(this, differCallback)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        return EventViewHolder(
            EventLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun getItemCount(): Int {
        return differ.currentList.size
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val currentEvent = differ.currentList[position]

        holder.itemBinding.eventTitle.text = currentEvent.eventTitle
        holder.itemBinding.eventDesc.text = currentEvent.eventDesc

        holder.itemView.setOnClickListener {
            val direction = HomeFragmentDirections.actionHomeFragmentToEditEventFragment(currentEvent)
            it.findNavController().navigate(direction)
        }
    }
}
